import { CustomIfDirective } from './custom-if.directive';

describe('CustomIfDirective', () => {
  it('should create an instance', () => {
    const directive = new CustomIfDirective();
    expect(directive).toBeTruthy();
  });
});
