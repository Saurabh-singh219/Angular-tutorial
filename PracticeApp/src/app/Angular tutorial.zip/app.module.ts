import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { PipesComponent } from './pipes/pipes.component';
import { DirectivesComponent } from './directives/directives.component';
import { ObservablesComponent } from './observables/observables.component';
import { FormsModule } from '@angular/forms';
import { SortingPipe } from './sorting.pipe';
import { CustomIfDirective } from './custom-if.directive';
import { DataTranferComponent } from './data-tranfer/data-tranfer.component';
import { ChildComponent } from './data-tranfer/child/child.component';
import { OthersComponent } from './others/others.component';

@NgModule({
  declarations: [
    AppComponent,
    PipesComponent,
    DirectivesComponent,
    ObservablesComponent,
    SortingPipe,
    CustomIfDirective,
    DataTranferComponent,
    ChildComponent,
    OthersComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
