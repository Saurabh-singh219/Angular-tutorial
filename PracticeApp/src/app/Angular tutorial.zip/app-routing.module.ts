import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DataTranferComponent } from './data-tranfer/data-tranfer.component';
import { DirectivesComponent } from './directives/directives.component';
import { ObservablesComponent } from './observables/observables.component';
import { PipesComponent } from './pipes/pipes.component';


const routes: Routes = [

  {path: 'dir', component: DirectivesComponent},
  {path: 'pip', component: PipesComponent},
  {path: 'obs', component: ObservablesComponent},
  {path: 'dat', component: DataTranferComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
