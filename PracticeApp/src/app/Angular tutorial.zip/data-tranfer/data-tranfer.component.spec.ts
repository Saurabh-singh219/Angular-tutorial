import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DataTranferComponent } from './data-tranfer.component';

describe('DataTranferComponent', () => {
  let component: DataTranferComponent;
  let fixture: ComponentFixture<DataTranferComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DataTranferComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DataTranferComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
