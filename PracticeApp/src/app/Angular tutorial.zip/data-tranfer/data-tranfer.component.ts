import { Component, OnInit } from '@angular/core';
import { CommonServiceService } from '../common-service.service';

@Component({
  selector: 'app-data-tranfer',
  templateUrl: './data-tranfer.component.html',
  styleUrls: ['./data-tranfer.component.css']
})
export class DataTranferComponent implements OnInit {
  data: any;
  serviceData: any;
  constructor(private service:CommonServiceService) { }

  currentItem="hello";
  ngOnInit() {
    this.serviceData=this.service.getFavColor();
  }
  getData(event){
this.data=event;
  }

}
