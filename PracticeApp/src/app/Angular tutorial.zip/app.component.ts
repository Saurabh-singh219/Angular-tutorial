import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'PracticeApp';
  table=[
    {name:"Pipes",link:'/pip'},
    {name:"Directives",link:'/dir'},
    {name:"Observable",link:'/obs'},
    {name:"Data Tranfer",link:'/dat'}
  ];
}
